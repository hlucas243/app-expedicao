from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.core.window import Window
from plyer import camera
import sqlite3, os
from datetime import datetime

from kivy.lang import Builder

# Carrega o arquivo KV (ui.kv) - ou renomeie para 'expedicao.kv' para auto-load
Builder.load_file('ui.kv')

# Tema escuro industrial
Window.clearcolor = (0.08, 0.08, 0.08, 1)

db_path = "expedicao.db"


# Caminho do banco: usa user_data_dir no dispositivo (Android), senão fallback para cwd
def get_db_path():
    try:
        app = App.get_running_app()
        if app:
            return os.path.join(app.user_data_dir, 'expedicao.db')
    except Exception:
        pass
    return os.path.join(os.getcwd(), 'expedicao.db')

def init_db():
    conn = sqlite3.connect(get_db_path())
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS op (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                numero_op TEXT,
                descricao TEXT,
                quantidade INTEGER,
                status TEXT,
                data_entrada TEXT,
                data_saida TEXT
                )""")
    c.execute("""CREATE TABLE IF NOT EXISTS op_localizacao (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                op_id INTEGER,
                corredor TEXT,
                quantidade INTEGER,
                criado_em TEXT
                )""")
    c.execute("""CREATE TABLE IF NOT EXISTS op_foto (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                op_id INTEGER,
                caminho_foto TEXT,
                criado_em TEXT
                )""")
    conn.commit()
    conn.close()
init_db()

# --- Funções de banco ---
def salvar_op(numero, descricao, qtd):
    conn = sqlite3.connect(get_db_path())
    c = conn.cursor()
    c.execute("INSERT INTO op (numero_op, descricao, quantidade, status, data_entrada) VALUES (?, ?, ?, ?, ?)",
              (numero, descricao, qtd, "Armazenada", datetime.now().strftime("%Y-%m-%d %H:%M")))
    conn.commit()
    conn.close()

def buscar_ops():
    conn = sqlite3.connect(get_db_path())
    c = conn.cursor()
    c.execute("SELECT id, numero_op, descricao, quantidade, status FROM op ORDER BY id DESC")
    data = c.fetchall()
    conn.close()
    return data

def atualizar_status(op_id, novo_status):
    conn = sqlite3.connect(get_db_path())
    c = conn.cursor()
    if novo_status == "Expedida":
        c.execute("UPDATE op SET status=?, data_saida=? WHERE id=?",
                  (novo_status, datetime.now().strftime("%Y-%m-%d %H:%M"), op_id))
    else:
        c.execute("UPDATE op SET status=? WHERE id=?", (novo_status, op_id))
    conn.commit()
    conn.close()

def salvar_localizacao(op_id, corredor, qtd):
    conn = sqlite3.connect(get_db_path())
    c = conn.cursor()
    c.execute("INSERT INTO op_localizacao (op_id, corredor, quantidade, criado_em) VALUES (?, ?, ?, ?)",
              (op_id, corredor, qtd, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def listar_localizacoes(op_id):
    conn = sqlite3.connect(get_db_path())
    c = conn.cursor()
    c.execute("SELECT corredor, quantidade, criado_em FROM op_localizacao WHERE op_id=? ORDER BY id", (op_id,))
    data = c.fetchall()
    conn.close()
    return data

class MainView(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", spacing=10, padding=10, **kwargs)
        Clock.schedule_once(self.build_ui, 0)
        self.ultimo_corredor = ''

    def build_ui(self, *args):
        self.clear_widgets()
        self.add_widget(Label(text="📦 EXPEDIÇÃO", font_size="28sp", color=(1,1,1,1)))
        botoes = [
            ("➕ Entrada de OP", self.entrada_op, (0.2,0.6,1,1)),
            ("🏷️ Dividir por Corredor", self.dividir_corredor, (0.3,0.8,0.4,1)),
            ("🚚 Saída de OP", self.saida_op, (1,0.5,0,1)),
            ("🔍 Pesquisa de OP", self.pesquisa_op, (0.8,0.3,1,1))
        ]
        for texto, func, cor in botoes:
            b = Button(text=texto, size_hint_y=None, height=60, background_color=cor)
            b.bind(on_release=func)
            self.add_widget(b)

    def entrada_op(self, *args):
        self.clear_widgets()
        self.add_widget(Label(text="Nova OP", font_size="22sp", color=(1,1,1,1)))
        self.numero = TextInput(hint_text="Número da OP", multiline=False)
        self.desc = TextInput(hint_text="Descrição", multiline=False)
        self.qtd = TextInput(hint_text="Quantidade", multiline=False, input_filter="int")
        self.add_widget(self.numero)
        self.add_widget(self.desc)
        self.add_widget(self.qtd)

        foto_btn = Button(text="📷 Adicionar Foto", background_color=(0.3,0.7,1,1))
        foto_btn.bind(on_release=self.tirar_foto)
        self.add_widget(foto_btn)

        salvar_btn = Button(text="Salvar", background_color=(0,0.8,0.4,1))
        salvar_btn.bind(on_release=self.salvar_op)
        self.add_widget(salvar_btn)

        voltar_btn = Button(text="⬅ Voltar", background_color=(0.8,0.2,0.2,1))
        voltar_btn.bind(on_release=lambda x: self.build_ui())
        self.add_widget(voltar_btn)

    def tirar_foto(self, *args):
        fotos_path = os.path.join(App.get_running_app().user_data_dir, 'fotos')
        os.makedirs(fotos_path, exist_ok=True)
        nome_arquivo = os.path.join(fotos_path, f"op_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg")
        try:
            camera.take_picture(filename=nome_arquivo, on_complete=self.foto_tirada)
            print(f"[INFO] Foto salva em {nome_arquivo}")
        except Exception as e:
            print("Erro ao tirar foto:", e)

def foto_tirada(self, path):
    if path:
        print(f"[INFO] Foto tirada com sucesso: {path}")
    else:
        print("[ERRO] A captura da foto falhou ou foi cancelada.")
    def salvar_op(self, *args):
        if self.numero.text and self.desc.text and self.qtd.text:
            salvar_op(self.numero.text, self.desc.text, int(self.qtd.text))
            print("[INFO] Expedição: OP salva com sucesso ✅")
            self.build_ui()

    def dividir_corredor(self, *args):
        self.clear_widgets()
        self.add_widget(Label(text="Dividir OP em Corredores", color=(1,1,1,1)))
        ops = buscar_ops()
        if not ops:
            self.add_widget(Label(text="Nenhuma OP cadastrada.", color=(1,1,1,1)))
        else:
            for op in ops:
                box = BoxLayout(size_hint_y=None, height=50)
                box.add_widget(Label(text=f"{op[1]} - {op[2]}", color=(1,1,1,1)))
                btn = Button(text="Dividir", background_color=(0.2,0.6,1,1))
                btn.bind(on_release=lambda x, op_id=op[0]: self.definir_corredor(op_id))
                box.add_widget(btn)
                self.add_widget(box)
        voltar = Button(text="⬅ Voltar", background_color=(0.8,0.2,0.2,1))
        voltar.bind(on_release=lambda x: self.build_ui())
        self.add_widget(voltar)

    def definir_corredor(self, op_id):
        self.clear_widgets()
        self.add_widget(Label(text=f"Adicionar corredor à OP {op_id}", color=(1,1,1,1)))
        self.corredor = TextInput(hint_text="Corredor (ex: A1)", multiline=False)
        self.qtd = TextInput(hint_text="Quantidade", multiline=False, input_filter="int")
        self.add_widget(self.corredor)
        self.add_widget(self.qtd)
        add_btn = Button(text="Adicionar", background_color=(0,0.8,0.4,1))
        add_btn.bind(on_release=lambda x: self.salvar_localizacao(op_id))
        self.add_widget(add_btn)
        voltar = Button(text="⬅ Voltar", background_color=(0.8,0.2,0.2,1))
        voltar.bind(on_release=lambda x: self.dividir_corredor())
        self.add_widget(voltar)

    def salvar_localizacao(self, op_id):
        if self.corredor.text and self.qtd.text:
            salvar_localizacao(op_id, self.corredor.text, int(self.qtd.text))
            self.ultimo_corredor = self.corredor.text
            print(f"[INFO] Corredor {self.corredor.text} salvo ✅")
            self.dividir_corredor()

    def saida_op(self, *args):
        self.show_ops("Saída")

    def pesquisa_op(self, *args):
        self.show_ops("Pesquisa")

    def show_ops(self, tipo):
        self.clear_widgets()
        ops = buscar_ops()
        if not ops:
            self.add_widget(Label(text="Nenhuma OP registrada.", color=(1,1,1,1)))
        else:
            for op in ops:
                box = BoxLayout(size_hint_y=None, height=60)
                detalhes = f"{op[1]} - {op[2]} ({op[4]})"
                box.add_widget(Label(text=detalhes, color=(1,1,1,1)))
                if tipo == "Saída" and op[4] != "Expedida":
                    btn = Button(text="Expedir", background_color=(1,0.5,0,1))
                    btn.bind(on_release=lambda x, op_id=op[0]: self.confirmar_saida(op_id))
                    box.add_widget(btn)
                self.add_widget(box)
        voltar = Button(text="⬅ Voltar", background_color=(0.8,0.2,0.2,1))
        voltar.bind(on_release=lambda x: self.build_ui())
        self.add_widget(voltar)

    def confirmar_saida(self, op_id):
        atualizar_status(op_id, "Expedida")
        print(f"[INFO] OP {op_id} expedida ✅")
        self.build_ui()

class ExpedicaoApp(App):
    def build(self):
        print("[INFO] Expedição carregado ✅")
        return MainView()

if __name__ == "__main__":
    ExpedicaoApp().run()